import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { category, search } = req.query;
      let query = supabase.from('products').select('*').order('created_at', { ascending: false });
      if (category && category !== 'All') {
        query = query.eq('category', category);
      }
      if (search) {
        query = query.ilike('name', `%${search}%`);
      }
      const { data, error } = await query;
      if (error) throw error;
      // Parse sizes/colors from comma-separated text to arrays
      const parsed = (data || []).map(p => ({
        ...p,
        sizes: p.sizes ? p.sizes.split(',').map(s => s.trim()) : [],
        colors: p.colors ? p.colors.split(',').map(c => c.trim()) : [],
      }));
      return res.status(200).json(parsed);
    }

    if (req.method === 'POST') {
      const { name, brand, category, price, image, description, sizes, colors } = req.body;
      const { data, error } = await supabase
        .from('products')
        .insert({
          name, brand, category, price, image, description,
          sizes: Array.isArray(sizes) ? sizes.join(',') : sizes,
          colors: Array.isArray(colors) ? colors.join(',') : colors,
        })
        .select()
        .single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
