import { motion } from 'framer-motion';
import { Plus, Star, Heart } from 'lucide-react';
import { useState } from 'react';

export interface Product {
  id: number;
  name: string;
  brand: string;
  category: string;
  price: number;
  image: string;
  description: string;
  sizes: string[];
  colors: string[];
}

interface Props {
  product: Product;
  index: number;
  onSelect: (p: Product) => void;
}

const categoryBadges: Record<string, string> = {
  Running: 'Best Seller',
  Basketball: 'Pro Grade',
  Lifestyle: 'Trending',
  Training: 'New',
};

export default function ProductCard({ product, index, onSelect }: Props) {
  const [liked, setLiked] = useState(false);
  const badge = categoryBadges[product.category] || 'New';

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 0.5, delay: (index % 4) * 0.08, ease: [0.22, 1, 0.36, 1] }}
      whileHover={{ y: -8 }}
      onClick={() => onSelect(product)}
      className="group cursor-pointer bg-zinc-900/60 rounded-2xl overflow-hidden border border-white/5 hover:border-lime-400/40 hover:shadow-2xl hover:shadow-lime-400/5 transition-all duration-300"
    >
      {/* Image */}
      <div className="relative aspect-square overflow-hidden bg-gradient-to-br from-zinc-800 via-zinc-900 to-black">
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

        {/* Badge */}
        <span className="absolute top-3 left-3 px-2.5 py-1 bg-lime-400 text-black text-[10px] font-bold uppercase tracking-wider rounded-md">
          {badge}
        </span>

        {/* Wishlist */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            setLiked(!liked);
          }}
          className="absolute top-3 right-3 w-8 h-8 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center hover:bg-black/60 transition-colors"
          aria-label="Add to wishlist"
        >
          <Heart
            size={15}
            className={liked ? 'fill-red-500 text-red-500' : 'text-white/70'}
          />
        </button>

        {/* Quick add */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          whileHover={{ y: 0, opacity: 1 }}
          className="absolute bottom-3 left-3 right-3 opacity-0 group-hover:opacity-100 group-hover:translate-y-0 translate-y-4 transition-all duration-300"
        >
          <button
            onClick={(e) => {
              e.stopPropagation();
              onSelect(product);
            }}
            className="w-full py-2.5 bg-white/95 backdrop-blur-sm text-black text-xs font-bold uppercase tracking-wider rounded-xl flex items-center justify-center gap-1.5 hover:bg-lime-400 transition-colors"
          >
            <Plus size={14} /> Quick Add
          </button>
        </motion.div>
      </div>

      {/* Info */}
      <div className="p-4">
        <div className="flex items-center justify-between mb-1">
          <p className="text-white/40 text-[10px] uppercase tracking-widest font-medium">{product.brand}</p>
          <div className="flex items-center gap-1">
            <Star size={11} className="fill-lime-400 text-lime-400" />
            <span className="text-white/40 text-[10px] font-medium">4.9</span>
          </div>
        </div>
        <h3 className="font-display text-white font-bold text-sm md:text-base truncate mb-2">{product.name}</h3>
        <div className="flex items-center justify-between">
          <span className="font-display text-lime-400 font-black text-lg">${product.price}</span>
          <div className="flex gap-1">
            {product.colors.slice(0, 3).map((c, i) => (
              <span
                key={i}
                className="w-3 h-3 rounded-full border border-white/20 ring-1 ring-black/20"
                style={{ backgroundColor: c }}
              />
            ))}
            {product.colors.length > 3 && (
              <span className="text-white/30 text-[9px] font-medium ml-0.5">+{product.colors.length - 3}</span>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
}
