import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, useScroll, useTransform } from 'framer-motion';
import { ArrowRight, Zap, Shield, Truck, Award, Star, Quote } from 'lucide-react';
import Marquee from '../components/Marquee';
import { Product } from '../components/ProductCard';

const categories = [
  { name: 'Running', desc: 'Engineered for speed', img: '/images/product-1.jpg' },
  { name: 'Lifestyle', desc: 'Everyday comfort', img: '/images/product-2.jpg' },
  { name: 'Basketball', desc: 'Dominate the court', img: '/images/product-3.jpg' },
  { name: 'Training', desc: 'Built for the grind', img: '/images/product-4.jpg' },
];

const testimonials = [
  { name: 'Marcus T.', role: 'Marathon Runner', text: 'STRYDE changed my game. The Velocity Pro shaved 3 minutes off my PR. Never going back.', rating: 5 },
  { name: 'Sarah K.', role: 'Verified Buyer', text: 'The quality is insane. I get compliments every time I wear them. Worth every penny.', rating: 5 },
  { name: 'James L.', role: 'Personal Trainer', text: 'My clients ask about my shoes every session. The Iron Forge is the best training shoe I have owned.', rating: 5 },
];

const container = {
  hidden: {},
  show: { transition: { staggerChildren: 0.08 } },
};
const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] as const } },
};

export default function Home() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const { scrollY } = useScroll();
  const heroY = useTransform(scrollY, [0, 500], [0, 150]);
  const heroScale = useTransform(scrollY, [0, 500], [1, 1.15]);
  const heroOpacity = useTransform(scrollY, [0, 400], [1, 0]);

  useEffect(() => {
    fetch('/api/products')
      .then((r) => r.json())
      .then((data) => {
        setProducts(data.slice(0, 4));
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const stats = [
    { value: '2M+', label: 'Happy Customers' },
    { value: '150+', label: 'Countries' },
    { value: '50+', label: 'Shoe Models' },
    { value: '4.9★', label: 'Avg Rating' },
  ];

  return (
    <div className="bg-black text-white overflow-x-hidden">
      {/* Hero */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <motion.div style={{ y: heroY, scale: heroScale, opacity: heroOpacity }} className="absolute inset-0 z-0">
          <img src="/images/hero-shoe.png" alt="" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/50 to-black" />
          <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-transparent to-black/30" />
        </motion.div>

        <motion.div
          variants={container}
          initial="hidden"
          animate="show"
          className="relative z-10 text-center px-5 max-w-5xl mx-auto pt-24"
        >
          <motion.div variants={item} className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-lime-400/10 border border-lime-400/30 mb-6">
            <Zap size={14} className="text-lime-400" />
            <span className="text-lime-400 text-xs font-bold uppercase tracking-widest">New Drop · Spring 2025</span>
          </motion.div>

          <motion.h1
            variants={item}
            className="font-display text-6xl md:text-8xl lg:text-9xl font-black italic tracking-tighter leading-[0.85]"
          >
            MOVE WITH
            <br />
            <span className="text-lime-400">PURPOSE</span>
          </motion.h1>

          <motion.p variants={item} className="text-white/60 text-lg md:text-xl mt-6 max-w-xl mx-auto leading-relaxed">
            Premium footwear engineered for athletes who refuse to compromise. Every step is a statement.
          </motion.p>

          <motion.div variants={item} className="flex flex-col sm:flex-row gap-4 justify-center mt-10">
            <Link
              to="/shop"
              className="group inline-flex items-center justify-center gap-2 px-8 py-4 bg-lime-400 text-black font-bold uppercase text-sm tracking-wide hover:bg-lime-300 hover:shadow-xl hover:shadow-lime-400/20 transition-all"
            >
              Shop the Collection
              <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
            </Link>
            <Link
              to="/shop?category=Running"
              className="inline-flex items-center justify-center gap-2 px-8 py-4 border border-white/20 text-white font-bold uppercase text-sm tracking-wide hover:bg-white/5 hover:border-white/40 transition-all"
            >
              Explore Running
            </Link>
          </motion.div>

          {/* Inline trust signals */}
          <motion.div variants={item} className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 mt-10 text-white/40 text-xs">
            <span className="flex items-center gap-1.5"><Truck size={14} className="text-lime-400" /> Free Shipping $75+</span>
            <span className="flex items-center gap-1.5"><Shield size={14} className="text-lime-400" /> 2-Year Warranty</span>
            <span className="flex items-center gap-1.5"><Star size={14} className="text-lime-400" /> 4.9/5 Rating</span>
          </motion.div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10"
        >
          <div className="w-6 h-10 rounded-full border-2 border-white/30 flex justify-center pt-2">
            <motion.div animate={{ y: [0, 8, 0] }} transition={{ repeat: Infinity, duration: 1.5 }} className="w-1 h-2 rounded-full bg-white/60" />
          </div>
        </motion.div>
      </section>

      <Marquee text="STRYDE · MOVE WITH PURPOSE · STRYDE · MOVE WITH PURPOSE" />

      {/* Stats */}
      <section className="py-16 md:py-24 px-5">
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="text-center"
            >
              <div className="font-display text-4xl md:text-6xl font-black italic text-lime-400 mb-1">{s.value}</div>
              <div className="text-white/50 text-xs md:text-sm uppercase tracking-wider">{s.label}</div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-12 md:py-24 px-5">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-end justify-between mb-8 md:mb-10">
            <div>
              <motion.p
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                className="text-lime-400 text-xs font-bold uppercase tracking-widest mb-2"
              >
                Best Sellers
              </motion.p>
              <motion.h2
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="font-display text-4xl md:text-6xl font-black italic tracking-tighter"
              >
                Featured Drops
              </motion.h2>
            </div>
            <Link to="/shop" className="hidden md:flex items-center gap-2 text-white/60 hover:text-lime-400 transition-colors text-sm font-medium uppercase tracking-wide">
              View All <ArrowRight size={16} />
            </Link>
          </div>

          {loading ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="aspect-[3/4] bg-zinc-900 rounded-2xl shimmer" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
              {products.map((p, i) => (
                <motion.div
                  key={p.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  whileHover={{ y: -8 }}
                  className="group cursor-pointer bg-zinc-900/60 rounded-2xl overflow-hidden border border-white/5 hover:border-lime-400/40 hover:shadow-2xl hover:shadow-lime-400/5 transition-all duration-300"
                  onClick={() => navigate(`/shop?product=${p.id}`)}
                >
                  <div className="relative aspect-square overflow-hidden bg-gradient-to-br from-zinc-800 via-zinc-900 to-black">
                    <img src={p.image} alt={p.name} loading="lazy" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    <span className="absolute top-3 left-3 px-2.5 py-1 bg-lime-400 text-black text-[10px] font-bold uppercase tracking-wider rounded-md">
                      {p.category}
                    </span>
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <span className="px-5 py-2.5 bg-white/95 backdrop-blur-sm text-black text-xs font-bold uppercase tracking-wider rounded-xl">
                        View Details
                      </span>
                    </div>
                  </div>
                  <div className="p-4">
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-white/40 text-[10px] uppercase tracking-widest font-medium">{p.brand}</p>
                      <div className="flex items-center gap-1">
                        <Star size={11} className="fill-lime-400 text-lime-400" />
                        <span className="text-white/40 text-[10px] font-medium">4.9</span>
                      </div>
                    </div>
                    <h3 className="font-display text-white font-bold text-sm md:text-base truncate mb-2">{p.name}</h3>
                    <span className="font-display text-lime-400 font-black text-lg">${p.price}</span>
                  </div>
                </motion.div>
              ))}
            </div>
          )}

          <div className="mt-8 md:hidden">
            <Link to="/shop" className="flex items-center justify-center gap-2 text-lime-400 text-sm font-medium uppercase tracking-wide">
              View All <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-12 md:py-24 px-5">
        <div className="max-w-7xl mx-auto">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-display text-4xl md:text-6xl font-black italic tracking-tighter mb-8 md:mb-10 text-center"
          >
            Shop by Category
          </motion.h2>
          <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-3 md:gap-6">
            {categories.map((cat, i) => (
              <motion.div
                key={cat.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <Link to={`/shop?category=${cat.name}`}>
                  <div className="group relative aspect-[3/4] rounded-2xl overflow-hidden bg-zinc-900">
                    <img src={cat.img} alt={cat.name} loading="lazy" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent" />
                    <div className="absolute bottom-0 left-0 right-0 p-4 md:p-5">
                      <h3 className="font-display text-xl md:text-2xl font-black italic text-white mb-1">{cat.name}</h3>
                      <p className="text-white/60 text-xs md:text-sm mb-2">{cat.desc}</p>
                      <span className="inline-flex items-center gap-1.5 text-lime-400 text-xs md:text-sm font-bold uppercase tracking-wide">
                        Shop <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
                      </span>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Brand Story */}
      <section className="py-12 md:py-24 px-5">
        <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-8 md:gap-10 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative aspect-[4/3] rounded-2xl overflow-hidden"
          >
            <img src="/images/brand-story.jpg" alt="Athlete running" className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
          </motion.div>
          <motion.div initial={{ opacity: 0, x: 30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
            <p className="text-lime-400 text-xs font-bold uppercase tracking-widest mb-3">Our Story</p>
            <h2 className="font-display text-4xl md:text-5xl font-black italic tracking-tighter mb-5">
              BORN FROM<br />THE STREETS
            </h2>
            <p className="text-white/60 text-base leading-relaxed mb-4">
              STRYDE was founded in 2018 by a group of athletes who believed that great footwear shouldn't compromise between performance and style. We engineer every shoe with cutting-edge technology and bold design.
            </p>
            <p className="text-white/60 text-base leading-relaxed mb-6">
              From the track to the street, every STRYDE shoe is crafted to move with you — wherever life takes you.
            </p>
            <Link to="/shop" className="inline-flex items-center gap-2 text-lime-400 font-bold uppercase text-sm tracking-wide hover:gap-3 transition-all">
              Discover Our Collection <ArrowRight size={16} />
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-12 md:py-24 px-5 border-t border-white/10">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-10"
          >
            <p className="text-lime-400 text-xs font-bold uppercase tracking-widest mb-2">Loved by Athletes</p>
            <h2 className="font-display text-4xl md:text-6xl font-black italic tracking-tighter">What They Say</h2>
          </motion.div>
          <div className="grid md:grid-cols-3 gap-4 md:gap-6">
            {testimonials.map((t, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-zinc-900/60 border border-white/5 rounded-2xl p-6 hover:border-lime-400/20 transition-colors"
              >
                <Quote size={28} className="text-lime-400/30 mb-3" />
                <div className="flex gap-0.5 mb-3">
                  {[...Array(t.rating)].map((_, j) => (
                    <Star key={j} size={14} className="fill-lime-400 text-lime-400" />
                  ))}
                </div>
                <p className="text-white/70 text-sm leading-relaxed mb-4">"{t.text}"</p>
                <div>
                  <p className="text-white font-semibold text-sm">{t.name}</p>
                  <p className="text-white/40 text-xs">{t.role}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-12 md:py-24 px-5 border-t border-white/10">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-10">
          {[
            { icon: Truck, title: 'Free Shipping', desc: 'On all orders over $75. Delivered in 2-3 business days.' },
            { icon: Shield, title: '2-Year Warranty', desc: 'Every pair backed by our quality guarantee.' },
            { icon: Award, title: 'Premium Materials', desc: 'Sourced responsibly, built to last.' },
          ].map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="text-center md:text-left"
            >
              <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-lime-400/10 border border-lime-400/30 mb-4">
                <f.icon size={24} className="text-lime-400" />
              </div>
              <h3 className="font-display text-xl font-bold text-white mb-2">{f.title}</h3>
              <p className="text-white/50 text-sm leading-relaxed">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
}
